# 00 · Git y GitHub

**Tiempo estimado:** 25 minutos
**Meta de este módulo:** tener tu cuenta de GitHub creada y este repositorio descargado
en tu computadora, usando la línea de comandos.

---

## Antes de leer: haz esto

No leas la teoría todavía. Primero mira esto:

👉 Abre en tu navegador: **https://github.com/explore**

Dale un vistazo de dos minutos. Vas a ver proyectos de código de gente de todo el mundo.
Busca uno que te llame la atención y ábrelo.

**Responde mentalmente:**
- ¿Cuántas personas trabajan en ese proyecto?
- ¿Cuándo fue el último cambio?
- ¿Puedes ver qué cambió exactamente?

Ahora sí, sigue leyendo.

---

## Qué es Git

Imagina que estás escribiendo un documento importante. Probablemente has hecho esto:

```
propuesta.docx
propuesta_v2.docx
propuesta_v2_FINAL.docx
propuesta_v2_FINAL_corregida.docx
propuesta_ESTA_SI_ES_LA_BUENA.docx
```

Todos lo hemos hecho. Y todos hemos terminado sin saber cuál era la buena.

**Git resuelve exactamente ese problema.** Git es un programa que guarda el historial
completo de un proyecto: cada cambio, quién lo hizo, cuándo, y por qué. Puedes volver a
cualquier punto anterior. Nunca más necesitas `_FINAL_v3`.

Git se llama un **sistema de control de versiones**. Es la herramienta estándar de la
industria: prácticamente todo el software del mundo se desarrolla con Git.

### Lo importante ahora

Git funciona **en tu computadora**. No necesita internet. Es un programa local.

---

## Qué es GitHub

Si Git vive en tu computadora, ¿cómo trabajan dos personas en el mismo proyecto?

**GitHub es una página web donde se guardan proyectos de Git en internet.** Es el lugar
común al que todos suben sus cambios y del que todos los descargan.

| | Git | GitHub |
|---|---|---|
| Qué es | Un programa | Una página web |
| Dónde vive | En tu computadora | En internet |
| Para qué sirve | Guardar el historial | Compartir el proyecto |
| ¿Necesita internet? | No | Sí |

Una analogía que funciona: **Git es Word, GitHub es Google Drive.** Uno es la herramienta
con la que trabajas; el otro es donde guardas y compartes el resultado.

> **Ojo:** existen alternativas a GitHub (GitLab, Bitbucket). GitHub es la más usada, y
> es donde está el material de este curso.

### Por qué te importa a ti

Tu cuenta de GitHub es tu **portafolio profesional**. Cuando busques trabajo como
técnico o desarrollador, es muy probable que te pidan el enlace. Todo lo que publiques
ahí queda visible. La cuenta que vas a crear hoy te va a servir por años.

---

## Vocabulario mínimo

Cinco palabras. Solo necesitas estas hoy:

| Palabra | Qué significa |
|---|---|
| **Repositorio** (o *repo*) | Una carpeta de proyecto con historial de Git |
| **Clonar** | Descargar una copia completa de un repositorio a tu computadora |
| **Commit** | Una "foto" guardada del proyecto en un momento dado |
| **Push** | Subir tus cambios a GitHub |
| **Pull** | Bajar los cambios que otros subieron |

Hoy solo vas a usar **clonar**. Las demás las vas a necesitar en Python II.

---

## Paso 1 · Crea tu cuenta de GitHub

**Tiempo: 8 minutos**

1. Ve a **https://github.com/signup**
2. **Correo electrónico:** usa un correo personal que vayas a conservar, no el
   institucional. Esta cuenta te va a servir después de graduarte.
3. **Contraseña:** mínimo 8 caracteres con al menos un número y una minúscula.
   Anótala donde no se te pierda.
4. **Nombre de usuario:** piénsalo bien.

### Sobre el nombre de usuario

Este nombre va a aparecer en tu portafolio profesional. Va a estar en tu currículum.

**Bien:** `jperez-dev`, `mariaramirez`, `jcastillo2026`
**Mal:** `xXelmatadorXx`, `papi_chulo507`, `asdfgh123`

Elige algo que no te dé pena enseñar en una entrevista de trabajo.

5. Completa la verificación y confirma tu correo.

✅ **Punto de control:** cuando puedas entrar a `https://github.com/TU-USUARIO` y ver tu
perfil, terminaste este paso.

---

## Paso 2 · Verifica que tienes Git instalado

**Tiempo: 2 minutos**

Necesitas abrir una **terminal** (también llamada consola o línea de comandos). Es una
ventana donde escribes comandos en lugar de hacer clic.

**En Windows:** presiona la tecla `Windows`, escribe `cmd` y presiona Enter.
**En macOS:** presiona `Cmd + Espacio`, escribe `Terminal` y presiona Enter.
**En Linux:** presiona `Ctrl + Alt + T`.

Se abre una ventana con texto. Escribe exactamente esto y presiona Enter:

```bash
git --version
```

**Si ves algo como `git version 2.43.0`** → perfecto, continúa al Paso 3.

**Si ves `'git' no se reconoce como un comando`** → Git no está instalado.
Levanta la mano; el facilitador te ayuda a instalarlo desde
https://git-scm.com/downloads

---

## Paso 3 · Clona este repositorio

**Tiempo: 10 minutos**

Ahora vas a descargar este material a tu computadora. Tres comandos.

### 3.1 · Ubícate en el Escritorio

```bash
cd Desktop
```

`cd` significa *change directory* (cambiar de carpeta). Le estás diciendo a la terminal
"muévete a la carpeta Escritorio".

> **Si tu Windows está en español** y `cd Desktop` te da error, prueba con:
> ```bash
> cd Escritorio
> ```

### 3.2 · Clona el repositorio

```bash
git clone https://github.com/guar0911/python-i-laboratorio.git
```

> ⚠️ **El facilitador va a escribir la dirección exacta en la pizarra.** Cópiala tal cual.

Vas a ver algo así:

```
Cloning into 'python-i-laboratorio'...
remote: Enumerating objects: 42, done.
remote: Total 42 (delta 0), reused 42 (delta 0)
Receiving objects: 100% (42/42), done.
```

**Eso es Git descargando el proyecto completo con todo su historial.**

### 3.3 · Entra a la carpeta y mira qué hay

```bash
cd python-i-laboratorio
```

Y luego, para ver el contenido:

```bash
dir
```

*(En macOS o Linux usa `ls` en lugar de `dir`.)*

Deberías ver las carpetas de los temas: `00-git-y-github`, `01-entorno-de-trabajo`,
`02-variables`, y las demás.

✅ **Punto de control:** si ves esa lista de carpetas, ya clonaste el repositorio.


---

## Paso 4 · Ábrelo en VS Code

Desde la misma terminal, estando dentro de la carpeta del proyecto:

```bash
code .
```

Ese punto significa *"la carpeta actual"*. VS Code se abre con el proyecto completo
cargado.

**Si `code` no se reconoce como comando**, ábrelo a mano:

1. Abre **Visual Studio Code**.
2. `Archivo → Abrir carpeta...`
3. Selecciona `Escritorio → python-i-laboratorio`
4. Pulsa **Seleccionar carpeta**

> ⚠️ Abre la **carpeta**, nunca un archivo suelto. Si abres solo el `.py`, VS Code no
> encuentra el resto del proyecto y varias cosas dejan de funcionar.

En el panel de la izquierda deberías ver las carpetas de los temas.

Ya estás listo para el siguiente módulo, donde terminas de configurar el editor.

---

## Errores comunes en este módulo

| Lo que ves | Qué pasó | Cómo lo arreglas |
|---|---|---|
| `'git' no se reconoce...` | Git no está instalado | Levanta la mano |
| `The system cannot find the path specified` | La carpeta `Desktop` no existe con ese nombre | Prueba `cd Escritorio` |
| `repository not found` | La dirección tiene un error de tipeo | Cópiala de nuevo de la pizarra |
| `destination path already exists` | Ya lo clonaste antes | Solo haz `cd python-i-laboratorio` |
| `fatal: not a git repository` | Estás fuera de la carpeta del proyecto | Haz `cd python-i-laboratorio` |

---

## Reto +

*Solo si terminaste antes que el resto.*

1. En GitHub, entra a este repositorio en el navegador y busca la pestaña **Commits**.
   ¿Cuántos cambios se han guardado? ¿Quién los hizo?
2. En tu terminal, dentro de la carpeta del proyecto, ejecuta:
   ```bash
   git log --oneline
   ```
   Compara lo que ves con lo que mostraba la página web. **Es exactamente la misma
   información**: una desde internet, otra desde tu disco duro. Eso es Git y GitHub
   siendo dos cosas distintas.

---

**Siguiente:** [`01-entorno-de-trabajo/`](../01-entorno-de-trabajo/)
