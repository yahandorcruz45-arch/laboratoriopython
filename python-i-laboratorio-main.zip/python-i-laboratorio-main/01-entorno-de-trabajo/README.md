# 01 · Entorno de trabajo

**Tiempo estimado:** 20 minutos
**Meta:** dejar VS Code configurado, ejecutar código Python y entender qué hacer cuando
falla.

---

## Configuración inicial

**Esto se hace una sola vez.** Son tres pasos y después no vuelves a tocarlo.

### 1 · Instala la extensión de Python

VS Code no sabe nada de Python hasta que se lo dices.

1. En la barra lateral izquierda, haz clic en el ícono de **Extensiones**
   (los cuatro cuadritos), o presiona `Ctrl + Shift + X` (`Cmd + Shift + X` en Mac).
2. En el buscador escribe: **Python**
3. Instala la primera, la de **Microsoft**. Debe decir *Microsoft* debajo del nombre.
4. Espera a que el botón cambie a "Desinstalar". Eso significa que quedó lista.

> Esta extensión trae también **Pylance**, que es lo que te va a subrayar los errores
> mientras escribes.

### 2 · Selecciona el intérprete

Ahora dile a VS Code **cuál** Python usar.

1. Presiona `Ctrl + Shift + P` (`Cmd + Shift + P` en Mac). Se abre una barra de búsqueda
   arriba: es la **paleta de comandos**, desde donde se hace casi todo en VS Code.
2. Escribe: **Python: Select Interpreter**
3. Elige el que diga **Python 3.13** o similar. Si aparecen varios, toma el de la
   versión más alta.

✅ **Punto de control:** abajo a la derecha, en la barra azul, debe aparecer la versión
de Python. Si no aparece, levanta la mano.

### 3 · Ejecuta tu primer archivo

1. En el panel izquierdo, abre `01-entorno-de-trabajo` → `ejemplos.py`
2. Presiona el **botón ▷ (Play)** arriba a la derecha.
3. Abajo se abre la **Terminal** con el resultado.

Si ves el reporte de producción impreso, ya está todo funcionando.

---

## Primero: ejecuta, después lee

1. Con `ejemplos.py` abierto, presiona ▷.
2. Haz los tres cambios que pide el final del archivo.
3. Abre **`reto.py`** y arregla los 3 errores.

Vuelve aquí cuando lo hayas intentado.

---

## Qué acabas de usar

### `print()` — mostrar algo en pantalla

```python
print("Hola")
```

Es la instrucción que más vas a usar hoy. Todo lo que pongas entre los paréntesis
aparece en la terminal.

Puedes combinar texto y datos separándolos con comas:

```python
piezas = 120
print("Total de piezas:", piezas)
```

```
Total de piezas: 120
```

Python pone el espacio entre ellos automáticamente.

### `#` — comentarios

```python
# Esta línea no se ejecuta
print("Esta sí")
```

Todo lo que va después de `#` en una línea es para humanos, no para Python. Úsalos para
explicar *por qué* haces algo, no *qué* haces.

---

## Las cuatro zonas de VS Code

| Zona | Dónde está | Qué es |
|---|---|---|
| **Explorador** | Izquierda | Los archivos del proyecto. Clic para abrir. |
| **Editor** | Centro | Donde escribes. Aquí no pasa nada hasta que ejecutas. |
| **Terminal** | Abajo | Donde aparecen los resultados y los errores. |
| **Barra de estado** | Abajo del todo, en azul | Muestra la versión de Python seleccionada. |

Atajos que vale la pena memorizar hoy:

| Atajo | Qué hace |
|---|---|
| `Ctrl + S` | Guardar. **VS Code no guarda solo.** |
| `Ctrl + Shift + P` | Paleta de comandos (desde ahí se hace todo) |
| `` Ctrl + ` `` | Abrir o cerrar la terminal |
| `Ctrl + /` | Comentar o descomentar la línea donde estés |

> **`Ctrl + S` es el importante.** A diferencia de otros editores, VS Code no guarda
> automáticamente. Si ejecutas y no ves tus cambios, casi siempre es que no guardaste:
> busca el **punto blanco** al lado del nombre del archivo en la pestaña — ese punto
> significa "hay cambios sin guardar".

---

## Leer un error

Esto es lo más importante del módulo. Cuando algo falla, la terminal te muestra algo así:

```
  File "reto.py", line 15
    print("Operador: Maria Fernandez"
         ^
SyntaxError: '(' was never closed
```

Se lee de abajo hacia arriba:

1. **`SyntaxError: '(' was never closed`** — qué pasó: abriste un paréntesis y no lo cerraste.
2. **`line 15`** — dónde: línea 15.
3. **`^`** — Python apunta al lugar exacto del problema.

**Un error no es un regaño. Es una dirección.** Python te está diciendo exactamente
dónde mirar.

---

## Los errores que vas a ver hoy

| Error | Qué significa | Causa típica |
|---|---|---|
| `SyntaxError` | Escribiste algo que Python no puede leer | Falta un paréntesis, comilla o dos puntos |
| `NameError` | Usaste un nombre que Python no conoce | `Print` en vez de `print`, o una variable mal escrita |
| `TypeError` | Mezclaste tipos de datos incompatibles | Sumar texto con número |
| `IndentationError` | El espaciado al inicio de la línea está mal | Falta o sobra sangría |
| `ZeroDivisionError` | Dividiste entre cero | Una lista vacía en un promedio |

Los vas a encontrar todos en las próximas cuatro horas. Vuelve a esta tabla cuando
aparezcan.

---

## Reglas que Python no perdona

1. **Las mayúsculas importan.** `print` funciona; `Print` no.
2. **Las comillas abren y cierran igual.** `"texto"` y `'texto'` sirven; `"texto'` no.
3. **Cada paréntesis que abre, cierra.**
4. **El espaciado al inicio de la línea es parte del código**, no decoración. Lo vas a
   ver en el módulo 03.

---

## Problemas del editor (no del código)

No todo lo que sale mal es un error de Python. Estos son del editor:

| Lo que ves | Qué pasó | Cómo lo arreglas |
|---|---|---|
| No aparece el botón ▷ | La extensión de Python no está instalada | Vuelve al paso 1 de la configuración |
| Ejecuto y no veo mis cambios | No guardaste | `Ctrl + S`. Busca el punto blanco en la pestaña |
| `python: command not found` | No hay intérprete seleccionado | `Ctrl + Shift + P` → Python: Select Interpreter |
| El explorador de la izquierda está vacío | Abriste un archivo, no la carpeta | `Archivo → Abrir carpeta...` y elige `python-i-laboratorio` |
| Subrayados amarillos o azules | Son sugerencias de estilo, no errores | Ignóralos. Solo los **rojos** rompen el código |
| La terminal muestra basura de antes | Quedó la salida anterior | Clic en la papelera de la terminal, o `` Ctrl + ` `` dos veces |

> **Los subrayados de colores confunden mucho al principio.** VS Code marca en rojo lo
> que está roto, y en amarillo o azul lo que *podría* mejorarse. Hoy solo te importan
> los rojos.

---

## 📦 Entornos virtuales (`.venv`)

> **Esto no lo necesitas hoy.** Hoy no vas a instalar nada: todo lo que usas viene con
> Python. Pero vas a oír hablar de esto constantemente, y en Python II lo vas a usar
> desde el primer día. Léelo ahora para que el nombre no te suene raro después.

### El problema que resuelve

Python trae muchas cosas incluidas, pero no todas. Cuando necesitas leer un Excel,
conectarte a una base de datos o hacer un gráfico, instalas una **librería**: código que
alguien más escribió y publicó para que tú no tengas que hacerlo.

Se instalan con `pip`, el gestor de paquetes de Python:

```bash
pip install pandas
```

Por defecto, eso instala la librería **en toda tu computadora**. Y ahí empieza el
problema.

Imagina que en enero haces un proyecto que necesita `pandas` versión 1.5. En marzo
empiezas otro que necesita `pandas` 2.0. Los instalas a los dos en la misma
computadora... y el segundo reemplaza al primero. **El proyecto de enero deja de
funcionar** y ni te enteras hasta que lo abres meses después.

En un equipo es peor: tu código corre en tu máquina, falla en la del compañero, y nadie
entiende por qué.

### Qué es un entorno virtual

Un entorno virtual es **una carpeta con una copia aislada de Python y sus librerías,
que vive dentro de tu proyecto**.

Cada proyecto tiene la suya. Lo que instalas en una no afecta a las demás ni al Python
del sistema. El proyecto de enero conserva su `pandas` 1.5 y el de marzo su 2.0, sin
pelearse.

La carpeta se suele llamar **`.venv`** (por *virtual environment*). El punto al inicio
hace que sea una carpeta oculta.

> **Una analogía:** el Python del sistema es la caja de herramientas compartida del
> taller — si alguien cambia una llave, todos se ven afectados. Un `.venv` es tu caja
> personal para un trabajo específico: tú decides qué metes, y nadie más la toca.

### Cómo se crea

Tres pasos. Desde la terminal, dentro de la carpeta de tu proyecto:

**1. Crear el entorno**

```bash
python -m venv .venv
```

*(En macOS y Linux suele ser `python3 -m venv .venv`.)*

Aparece una carpeta `.venv/`. Eso es todo lo que hace este comando.

**2. Activarlo**

Este paso **cambia según el sistema operativo**:

```bash
# Windows (CMD o PowerShell)
.venv\Scripts\activate

# macOS y Linux
source .venv/bin/activate
```

Sabes que funcionó porque tu terminal ahora muestra `(.venv)` al inicio de la línea:

```
(.venv) C:\Users\maria\mi-proyecto>
```

**Ese `(.venv)` es la señal de que estás dentro.** Si no lo ves, no está activo y `pip`
va a instalar en todo el sistema.

**3. Instalar lo que necesites**

```bash
pip install pandas
```

Ahora `pandas` vive **solo** dentro de `.venv`, en este proyecto.

### Para salir

```bash
deactivate
```

El `(.venv)` desaparece y vuelves al Python del sistema.

### Dos cosas que hay que saber

**Hay que activarlo cada vez.** Si cierras la terminal y la vuelves a abrir, el entorno
ya no está activo. Se reactiva con el mismo comando del paso 2 — no hay que volver a
crearlo.

**`.venv` nunca se sube a GitHub.** Pesa cientos de megabytes y depende de tu sistema
operativo: lo que funciona en tu Windows no sirve en el Mac de tu compañero. Por eso el
`.gitignore` de este repositorio ya lo tiene excluido:

```
venv/
env/
.venv/
```

Lo que sí se comparte es la **lista** de librerías necesarias:

```bash
pip freeze > requirements.txt
```

Ese archivo de texto sí va al repositorio. Quien clone el proyecto crea su propio
`.venv` y lo instala todo de un golpe:

```bash
pip install -r requirements.txt
```

**Ese es el flujo profesional completo**, y es exactamente lo que vas a hacer en
Python II.

### En VS Code

VS Code detecta los entornos virtuales solo. Si creas un `.venv` dentro de la carpeta
del proyecto, aparece un aviso ofreciendo usarlo — dile que sí. También puedes
seleccionarlo a mano con `Ctrl + Shift + P` → **Python: Select Interpreter**: los `.venv`
del proyecto salen en la lista marcados como *Recommended*.

La barra azul de abajo siempre te dice cuál está activo. Esa es la forma rápida de
comprobar si estás dentro del entorno o en el Python del sistema.

Para hoy, déjalo como está.

---

## Reto +

*Solo si terminaste antes.*

Escribe un programa que imprima una ficha de producción formateada así:

```
+--------------------------------+
| PLANTA:    Santiago Norte      |
| LINEA:     A-12                |
| PIEZAS:    340                 |
+--------------------------------+
```

Usa varias llamadas a `print()`. Pista: `print()` sin nada adentro imprime una línea en
blanco.

### Reto + + (entorno virtual)

*Solo si ya hiciste el anterior y quieres adelantarte a Python II.*

En tu terminal, **fuera** de la carpeta del curso:

```bash
mkdir prueba-venv
cd prueba-venv
python -m venv .venv
```

Actívalo con el comando de tu sistema operativo y confirma que aparece `(.venv)` al
inicio de la línea. Luego:

```bash
pip list
```

Vas a ver una lista casi vacía: es un Python limpio, sin nada instalado. Compárala con
la que sale al ejecutar `pip list` **después** de hacer `deactivate`.

Esa diferencia es exactamente lo que hace un entorno virtual.

---

**Siguiente:** [`02-variables/`](../02-variables/)
