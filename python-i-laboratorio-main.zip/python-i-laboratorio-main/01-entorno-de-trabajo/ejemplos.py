# =============================================================
# 01 · ENTORNO DE TRABAJO — Ejemplos
# =============================================================
# INSTRUCCIONES:
#   1. Guarda con Ctrl+S y presiona el boton > (Play).
#   2. Mira el resultado abajo, en la Terminal.
#   3. Luego sigue las instrucciones del final del archivo.
# =============================================================


# --- 1. print() muestra cosas en pantalla -------------------
print("Reporte de produccion")
print(" ")

print("yahandor cruz")
print(" ")
# --- 2. Todo lo que empieza con # es un comentario -----------
# Python ignora estas lineas por completo.

# Sirven para dejar notas a otros humanos (y a tu yo del futuro).
# print("Esta linea NO se ejecuta porque esta comentada")


# --- 3. Guardar datos con nombres ---------------------------
piezas = 200
rechazos = 8

print("Piezas producidas:", piezas)
print(" ")
print("Piezas rechazadas:", rechazos)
print(" ")


# --- 4. Python tambien calcula ------------------------------
print("Piezas buenas:", piezas - rechazos)
print(" ")


# =============================================================
# AHORA TE TOCA A TI
# =============================================================
# Haz estos tres cambios, ejecutando despues de cada uno:
#
#   A) Cambia el valor de 'piezas' a 200 y ejecuta otra vez.
#      Fijate como cambia TODO lo que depende de esa linea.
#
#   B) Agrega abajo una linea que imprima tu propio nombre.
#
#   C) Rompe el codigo a proposito: borra la comilla final de
#      la linea 16 (la de "Reporte de produccion") y ejecuta.
#      Lee el error que aparece. Luego vuelve a ponerla.
#
# El punto del ejercicio C es que veas un error hoy, temprano,
# y sin consecuencias. Los errores son parte normal del trabajo.
# =============================================================
