# ==========================================================
# PROYECTO: REGRESIÓN LINEAL
# CARRERA: BASES DE DATOS
#
# Este programa estima el tiempo de ejecución de una consulta
# SQL dependiendo de la cantidad de registros procesados.
#
# Todo lo que está escrito como comentario (#) es información
# destinada únicamente al programador y no será mostrada
# al usuario.
# ==========================================================


# ----------------------------------------------------------
# DATOS UTILIZADOS PARA CREAR EL MODELO
# ----------------------------------------------------------

registros = [100, 200, 300, 400, 500]

tiempo = [10, 20, 30, 40, 50]


# ----------------------------------------------------------
# CÁLCULO DE LA REGRESIÓN LINEAL
# ----------------------------------------------------------

n = len(registros)

suma_x = 0
suma_y = 0
suma_xy = 0
suma_x2 = 0

for i in range(n):

    suma_x = suma_x + registros[i]

    suma_y = suma_y + tiempo[i]

    suma_xy = suma_xy + (
        registros[i] * tiempo[i]
    )

    suma_x2 = suma_x2 + (
        registros[i] ** 2
    )


# ----------------------------------------------------------
# CÁLCULO DE LA PENDIENTE
# ----------------------------------------------------------

m = (
    (n * suma_xy) - (suma_x * suma_y)
) / (
    (n * suma_x2) - (suma_x ** 2)
)


# ----------------------------------------------------------
# CÁLCULO DEL INTERCEPTO
# ----------------------------------------------------------

b = (
    suma_y - (m * suma_x)
) / n


# ----------------------------------------------------------
# INTERFAZ DEL USUARIO
# ----------------------------------------------------------

print("==================================================")
print("          PREDICCIÓN DE TIEMPO SQL")
print("==================================================")


# ----------------------------------------------------------
# ENTRADA DEL USUARIO
# ----------------------------------------------------------

print("\nIngrese la cantidad de registros que desea analizar.")

nuevos_registros = float(
    input("Cantidad de registros: ")
)


# ----------------------------------------------------------
# REALIZAR LA PREDICCIÓN
# ----------------------------------------------------------

tiempo_estimado = (
    m * nuevos_registros
) + b


# ----------------------------------------------------------
# MOSTRAR RESULTADOS DETALLADOS
# ----------------------------------------------------------

print("\n==================================================")
print("                 RESULTADOS")
print("==================================================")

print("\nDatos de la consulta:")
print("------------------------------------------")

print(
    "Cantidad de registros:",
    nuevos_registros
)

print(
    "Tiempo estimado:",
    tiempo_estimado,
    "ms"
)

print(
    "Tiempo estimado en segundos:",
    tiempo_estimado / 1000,
    "segundos"
)


# ----------------------------------------------------------
# MOSTRAR EL MODELO
# ----------------------------------------------------------

print("\nModelo utilizado:")
print("------------------------------------------")

print(
    "Tiempo =",
    round(m, 4),
    "* Registros +",
    round(b, 4)
)


# ----------------------------------------------------------
# MOSTRAR LA INTERPRETACIÓN
# ----------------------------------------------------------

print("\nInterpretación:")
print("------------------------------------------")

print(
    "Por cada registro procesado, el tiempo aumenta"
)

print(
    "aproximadamente",
    round(m, 4),
    "milisegundos."
)


# ----------------------------------------------------------
# RESUMEN FINAL
# ----------------------------------------------------------

print("\n==================================================")
print("                  RESUMEN")
print("==================================================")

print(
    "La consulta procesará:",
    nuevos_registros,
    "registros."
)

print(
    "El tiempo estimado de ejecución es:",
    tiempo_estimado,
    "ms."
)

print(
    "Equivalente a aproximadamente:",
    round(tiempo_estimado / 1000, 4),
    "segundos."
)

print("\n==================================================")
print("             PROCESO FINALIZADO")
print("==================================================")