# 02 · Variables y tipos de datos

**Tiempo estimado:** 45 minutos
**Meta:** guardar datos, distinguir texto de número, y convertir entre ellos.

---

## Orden de trabajo

1. Abre **`reto.py`** y trata de arreglarlo. **Empieza por aquí**, aunque no sepas cómo.
2. Cuando lo logres (o cuando el facilitador lo indique), lee esta teoría.
3. Abre **`ejemplos.py`** y experimenta.

---

## Qué es una variable

Una variable es un **nombre que apunta a un valor**.

```python
piezas = 120
```

Esto se lee: *"la variable `piezas` guarda el valor 120"*. A partir de esa línea, cada
vez que escribas `piezas`, Python pone 120 en su lugar.

El signo `=` **no significa "es igual a"**. Significa **"guarda esto aquí"**. Se lee de
derecha a izquierda: toma el 120, mételo en `piezas`.

Puedes cambiar el valor cuando quieras:

```python
piezas = 120
piezas = 200      # ahora vale 200, el 120 se perdio
```

### Cómo nombrar variables

**Reglas obligatorias:**
- Sin espacios: `precio_unitario`, no `precio unitario`
- No empiezan con número: `linea1` sí, `1linea` no
- Las mayúsculas importan: `Piezas` y `piezas` son dos variables distintas

**Buena práctica:** nombres descriptivos en minúscula, separados por guión bajo.

```python
total_rechazos = 8          # bien
tr = 8                      # mal: ¿qué es "tr"?
x = 8                       # mal
```

> El código se escribe una vez y se lee cien. Escribe pensando en quien lo va a leer
> dentro de seis meses — que probablemente seas tú.

---

## Los cuatro tipos que necesitas hoy

| Tipo | Qué guarda | Ejemplo |
|---|---|---|
| `str` | Texto (*string*) | `"Maria Fernandez"`, `"A-12"` |
| `int` | Número entero | `120`, `-4`, `0` |
| `float` | Número con decimales | `36.5`, `340.00` |
| `bool` | Verdadero o falso | `True`, `False` |

El texto **siempre va entre comillas**. Los números **nunca**.

```python
operador = "Maria"     # str
piezas = 120           # int
temperatura = 36.5     # float
activo = True          # bool
```

Para saber de qué tipo es algo, usa `type()`:

```python
print(type(piezas))    # <class 'int'>
```

---

## El punto clave: `"120"` no es `120`

Esto es lo que rompía `reto.py`, y es el error más común de todo principiante.

```python
numero = 120        # int
texto  = "120"      # str
```

En pantalla se ven idénticos. Para Python son cosas completamente distintas:

```python
print(numero * 2)   # 240        <- multiplica
print(texto * 2)    # 120120     <- repite el texto
```

Y si mezclas los dos, Python se niega:

```python
"15" * 340.00
```
```
TypeError: can't multiply sequence by non-int of type 'float'
```

### 💡 Si ya usaste Excel

Te ha pasado esto: una columna de números no suma, y descubres que las celdas estaban
formateadas como texto. Excel te lo avisa con un triangulito verde en la esquina.

**Es exactamente el mismo problema.** La diferencia es que Python no te avisa con un
triangulito: te detiene con un `TypeError`.

---

## Convertir entre tipos

Tres funciones:

```python
int("120")        # 120      texto -> entero
float("36.5")     # 36.5     texto -> decimal
str(120)          # "120"    numero -> texto
```

```python
cantidad = "15"
total = int(cantidad) * 340.00    # ahora sí funciona
```

Ojo: `int("hola")` falla. Solo se puede convertir lo que realmente parece un número.

---

## `input()` siempre devuelve texto

**Guarda esto.** Es la causa de la mitad de los errores en las próximas horas:

```python
edad = input("Tu edad: ")
print(edad + 1)     # TypeError!
```

Aunque el usuario escriba `25`, `input()` entrega `"25"` — texto. Siempre.

La forma correcta:

```python
edad = int(input("Tu edad: "))
print(edad + 1)     # ahora sí
```

Para decimales, `float()`:

```python
precio = float(input("Precio: "))
```

---

## Operaciones útiles

```python
a + b     # suma (con texto, une: "Hola" + " mundo")
a - b     # resta
a * b     # multiplica (con texto, repite)
a / b     # divide (siempre da float: 10 / 2 -> 5.0)
a // b    # division entera (10 // 3 -> 3)
a % b     # resto (10 % 3 -> 1)
```

Y para presentar resultados:

```python
round(45.6789, 2)    # 45.68
```

---

## Errores de este módulo

| Error | Causa | Solución |
|---|---|---|
| `TypeError: can't multiply sequence...` | Multiplicaste texto por decimal | `int()` o `float()` |
| `TypeError: can only concatenate str...` | Usaste `+` entre texto y número | `str()` en el número |
| `NameError: name 'x' is not defined` | La variable no existe o está mal escrita | Revisa mayúsculas y tipeo |
| `ValueError: invalid literal for int()` | Intentaste convertir algo que no es número | Revisa lo que llega |

---

## Reto +

Amplía `reto.py` para que pida los datos al usuario y calcule el ITBIS:

```
Cantidad de piezas: 15
Precio unitario: 340
Subtotal: 5100.0
ITBIS (18%): 918.0
Total: 6018.0
```

---

**Siguiente:** [`03-condicionales/`](../03-condicionales/)
