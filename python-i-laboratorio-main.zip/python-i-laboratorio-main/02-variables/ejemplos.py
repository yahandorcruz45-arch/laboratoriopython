# =============================================================
# 02 · VARIABLES Y TIPOS — Ejemplos
# =============================================================
# Ejecuta este archivo y ve leyendo los resultados en la
# terminal. Cada bloque muestra algo distinto.
# =============================================================


# --- 1. Una variable es un nombre con un valor adentro ------
operador = "Maria Fernandez"
piezas = 120
temperatura = 36.5
turno_activo = True

print(operador)
print(piezas)
print(temperatura)
print(turno_activo)


# --- 2. Los cuatro tipos que vas a usar hoy -----------------
# type() te dice de que tipo es un valor.
print("---- tipos ----")
print(type(operador))      # str   -> texto
print(type(piezas))        # int   -> numero entero
print(type(temperatura))   # float -> numero con decimales
print(type(turno_activo))  # bool  -> verdadero o falso


# --- 3. "120" NO es lo mismo que 120 ------------------------
numero_real = 120
numero_texto = "120"

print("---- se ven igual ----")
print(numero_real)
print(numero_texto)

print("---- pero no lo son ----")
print(type(numero_real))
print(type(numero_texto))

# Con numeros, * multiplica:
print(numero_real * 2)     # 240

# Con texto, * repite:
print(numero_texto * 2)    # 120120


# --- 4. Convertir de un tipo a otro -------------------------
convertido = int(numero_texto)   # de texto a entero
print(convertido * 2)            # ahora si da 240

print(float("36.5") + 1)         # de texto a decimal
print(str(120) + " piezas")      # de entero a texto


# --- 5. Pedirle datos al usuario ----------------------------
# OJO: input() SIEMPRE devuelve texto, aunque escribas un numero.
# Por eso casi siempre hay que envolverlo en int() o float().
#
# Descomenta estas 3 lineas (quitales el #) y ejecuta:
#
# cantidad = int(input("Cuantas piezas? "))
# print("El doble seria:", cantidad * 2)


# --- 6. Calculo completo: cotizacion con ITBIS --------------
cantidad = 15
precio_unitario = 340.00

subtotal = cantidad * precio_unitario
itbis = subtotal * 0.18
total = subtotal + itbis

print("---- cotizacion ----")
print("Subtotal:", subtotal)
print("ITBIS:", itbis)
print("Total:", round(total, 2))   # round() redondea a 2 decimales


# =============================================================
# AHORA TE TOCA A TI
# =============================================================
#   A) Cambia 'cantidad' a 40 y ejecuta. Revisa el total.
#
#   B) Crea dos variables tuyas: tu nombre y tu edad.
#      Imprimelas en una sola linea usando una coma.
#
#   C) Intenta esto y mira el error que sale:
#         print("La edad es: " + 25)
#      Luego arreglalo usando str().
# =============================================================
