# =============================================================
# 02 · VARIABLES Y TIPOS — Reto
# =============================================================
# SITUACION:
#   Este script calcula el total de un pedido. Esta en produccion
#   y un cliente recibio una factura mal. Hay que arreglarlo.
#
#   Ejecutalo, lee el error, y arreglalo.
#   Puedes buscar en internet. Tienes 18 minutos.
# =============================================================


cantidad = "15"
precio_unitario = 340.00

total = cantidad * precio_unitario

print("Total a pagar:", total)


# =============================================================
# PREGUNTAS PARA CUANDO YA FUNCIONE
# =============================================================
#   1. Que decia el error exactamente? Que palabras se repetian?
#
#   2. Antes de arreglarlo, prueba esto en su lugar:
#           total = cantidad * 3
#      Ejecuta. Que salio? Por que crees que Python hizo eso?
#
#   3. Cuando le pides un numero al usuario con input(),
#      de que tipo llega?
#
# RESULTADO ESPERADO: Total a pagar: 5100.0
# =============================================================


# =============================================================
# RETO +  (solo si ya terminaste)
# =============================================================
#   Amplia el script para que:
#     - Pida la cantidad y el precio al usuario con input()
#     - Calcule el ITBIS (18%)
#     - Imprima subtotal, ITBIS y total, todos con 2 decimales
# =============================================================
