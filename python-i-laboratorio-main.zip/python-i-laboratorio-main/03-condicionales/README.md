# 03 · Condicionales

**Tiempo estimado:** 50 minutos
**Meta:** que tu programa tome decisiones.

---

## Orden de trabajo

1. Abre **`reto.py`** e intenta arreglarlo. Sí, antes de leer la teoría.
2. Lee esta página.
3. Experimenta con **`ejemplos.py`**.

---

## La idea

Hasta ahora tus programas ejecutan todas las líneas, siempre, en orden. Un condicional
permite que **cierto código se ejecute solo si se cumple una condición**.

```python
if lectura > 14.0:
    print("RECHAZADO")
```

Se lee tal cual: *si la lectura es mayor que 14.0, imprime RECHAZADO*. Si no lo es,
Python salta esa línea como si no existiera.

---

## Las tres formas

### `if` — haz algo, o no

```python
if lectura > LIMITE_ALTO:
    print("RECHAZADO")
```

### `if` / `else` — dos caminos

```python
if lectura > LIMITE_ALTO:
    print("RECHAZADO")
else:
    print("APROBADO")
```

`else` no lleva condición: es *"en cualquier otro caso"*.

### `if` / `elif` / `else` — tres o más caminos

```python
if lectura < LIMITE_BAJO:
    print("RECHAZADO - por debajo")
elif lectura > LIMITE_ALTO:
    print("RECHAZADO - por encima")
else:
    print("APROBADO")
```

`elif` es la contracción de *else if*. Puedes poner todos los que quieras.

> **El orden importa muchísimo.** Python evalúa de arriba hacia abajo y **se detiene en
> la primera condición verdadera**. Las demás ni las mira. Por eso en `reto.py` el caso
> `lectura = 0` nunca llega a `SENSOR DESCONECTADO`: cero también es menor que 10, así
> que entra por la primera rama.

---

## La indentación es sintaxis

Esto es lo que más confunde al venir de otros lenguajes o de Excel.

**Los espacios al inicio de la línea le dicen a Python qué está dentro de qué.**

```python
if lectura > 14.0:
    print("Dentro del if")      # 4 espacios: dentro
    print("Tambien dentro")     # 4 espacios: dentro
print("Fuera del if")           # 0 espacios: fuera, siempre se ejecuta
```

Reglas:

1. Después de una línea que termina en `:` **siempre** viene un bloque indentado.
2. Usa **4 espacios**. VS Code los pone solos cuando presionas Enter después de los `:`.
3. Todo el bloque lleva la **misma** cantidad de espacios.
4. No mezcles tabulaciones con espacios. Si copias código de internet, esto te va a
   morder.

Si te equivocas, Python te lo dice:

```
IndentationError: expected an indented block after 'if' statement on line 15
```

---

## Comparar: `==` no es `=`

| Operador | Qué hace | Ejemplo |
|---|---|---|
| `=` | **Guarda** un valor | `lectura = 12.0` |
| `==` | **Compara** si son iguales | `lectura == 12.0` |
| `!=` | Distinto de | `turno != "nocturno"` |
| `>` `<` | Mayor / menor que | `lectura > 14.0` |
| `>=` `<=` | Mayor o igual / menor o igual | `lectura >= 10.0` |

Una comparación siempre produce `True` o `False`:

```python
print(12.0 > 14.0)     # False
```

Confundir `=` con `==` dentro de un `if` es un error clásico. Python lo detecta:

```
SyntaxError: invalid syntax. Maybe you meant '==' instead of '='?
```

---

## Combinar condiciones

```python
# or  -> basta con que UNA se cumpla
if lectura < LIMITE_BAJO or lectura > LIMITE_ALTO:
    print("Fuera de rango")

# and -> se tienen que cumplir TODAS
if lectura < LIMITE_BAJO and turno == "nocturno":
    print("Avisar al supervisor")
```

| | Se cumple cuando |
|---|---|
| `and` | **ambas** condiciones son verdaderas |
| `or` | **al menos una** es verdadera |

---

## 💡 Si ya usaste Excel

Esto ya lo sabes hacer:

```
=SI(A1>14; "RECHAZADO"; "APROBADO")
```

En Python es:

```python
if a1 > 14:
    print("RECHAZADO")
else:
    print("APROBADO")
```

Y cuando en Excel necesitas tres resultados, terminas anidando un `SI` dentro de otro:

```
=SI(A1<10; "BAJO"; SI(A1>14; "ALTO"; "OK"))
```

Con cuatro o cinco casos eso se vuelve ilegible. En Python es `elif`, y se sigue leyendo
de arriba hacia abajo por muchos casos que agregues. **Esa es una de las razones reales
por las que se pasa de Excel a Python.**

---

## Errores de este módulo

| Error | Causa |
|---|---|
| `SyntaxError: expected ':'` | Falta los dos puntos al final del `if` |
| `IndentationError: expected an indented block` | El bloque después de `:` no está indentado |
| `IndentationError: unexpected indent` | Sobran espacios al inicio |
| `SyntaxError: ... Maybe you meant '=='` | Usaste `=` dentro de un `if` |

---

## Reto +

Agrega a `reto.py` una advertencia de proximidad: si la lectura está aprobada pero a
menos de `0.5` de cualquier límite, imprime `APROBADO - atencion, cerca del limite`.

Verifica: `13.8` → advertencia. `12.0` → aprobado normal. `10.3` → advertencia.

---

**Siguiente:** [`04-ciclos/`](../04-ciclos/)
