# =============================================================
# 03 · CONDICIONALES — Ejemplos
# =============================================================
# Control de calidad: una lectura esta dentro o fuera de rango.
# =============================================================


LIMITE_BAJO = 10.0
LIMITE_ALTO = 14.0
# NOTA: las variables en MAYUSCULAS son una convencion.
# Significan "esto no deberia cambiar durante el programa".


# --- 1. La decision mas simple: if --------------------------
lectura = 15.7

if lectura > LIMITE_ALTO:
    print("RECHAZADO - por encima del rango")


# --- 2. if / else: dos caminos ------------------------------
print("---- con else ----")

if lectura > LIMITE_ALTO:
    print("RECHAZADO")
else:
    print("APROBADO")


# --- 3. if / elif / else: tres o mas caminos ----------------
print("---- tres casos ----")
lectura = 8.3

if lectura < LIMITE_BAJO:
    print("RECHAZADO - por debajo del rango")
elif lectura > LIMITE_ALTO:
    print("RECHAZADO - por encima del rango")
else:
    print("APROBADO")


# --- 4. La indentacion es OBLIGATORIA -----------------------
# Los 4 espacios al inicio le dicen a Python "esto esta DENTRO
# del if". No es decoracion: es sintaxis.

lectura = 12.0

if lectura > LIMITE_ALTO:
    print("Esta linea esta DENTRO del if")
    print("Esta tambien")
print("Esta esta FUERA: se ejecuta siempre")


# --- 5. Combinar condiciones: and / or ----------------------
print("---- and / or ----")
lectura = 9.5
turno = "nocturno"

# or  -> basta con que UNA sea verdadera
if lectura < LIMITE_BAJO or lectura > LIMITE_ALTO:
    print("Fuera de rango")

# and -> tienen que ser AMBAS verdaderas
if lectura < LIMITE_BAJO and turno == "nocturno":
    print("Fuera de rango en turno nocturno: avisar al supervisor")


# --- 6. Comparar es distinto de asignar ---------------------
#   =   guarda un valor    ->  lectura = 12.0
#   ==  compara dos cosas  ->  lectura == 12.0

print("---- comparaciones ----")
print(12.0 == 12.0)    # True
print(12.0 != 15.0)    # True  (!= es "distinto de")
print(12.0 > 15.0)     # False
print(12.0 <= 12.0)    # True


# =============================================================
# AHORA TE TOCA A TI
# =============================================================
#   A) Cambia el valor de 'lectura' en el bloque 3 por 12.5
#      y ejecuta. Cual de las tres ramas se activo?
#
#   B) Agrega una cuarta situacion al bloque 3: si la lectura
#      es exactamente 0, imprimir "SENSOR DESCONECTADO".
#      Pista: tiene que ir ANTES de las otras comparaciones.
#
#   C) Rompe el codigo: quita los 4 espacios de sangria de
#      alguna linea que este dentro de un if. Ejecuta y lee
#      el IndentationError.
# =============================================================
