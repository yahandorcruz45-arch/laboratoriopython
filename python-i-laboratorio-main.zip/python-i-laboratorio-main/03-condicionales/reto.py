# =============================================================
# 03 · CONDICIONALES — Reto
# =============================================================
# SITUACION:
#   El supervisor pidio un chequeo de calidad con 3 categorias.
#   El script tiene 3 errores. Arreglalos uno por uno.
# =============================================================


LIMITE_BAJO = 10.0
LIMITE_ALTO = 14.0

lectura = 15.7


# Error 1: falta algo al final de esta linea
if lectura < LIMITE_BAJO
    print("RECHAZADO - por debajo del rango")

# Error 2: esta linea deberia estar DENTRO del elif
elif lectura > LIMITE_ALTO:
print("RECHAZADO - por encima del rango")

# Error 3: aqui se esta asignando en vez de comparar
elif lectura = 0:
    print("SENSOR DESCONECTADO")

else:
    print("APROBADO")


# =============================================================
# RESULTADO ESPERADO con lectura = 15.7:
#
#   RECHAZADO - por encima del rango
#
# Cuando funcione, PRUEBALO con estos valores cambiando
# la linea 13. Debe dar:
#
#   lectura = 8.3   ->  RECHAZADO - por debajo del rango
#   lectura = 12.0  ->  APROBADO
#   lectura = 0     ->  ???
#
# Con lectura = 0 pasa algo raro. Que salio? Por que?
# (Pista: revisa en que ORDEN estan las condiciones.)
# =============================================================


# =============================================================
# RETO +  (solo si ya terminaste)
# =============================================================
#   Agrega una advertencia: si la lectura esta APROBADA pero a
#   menos de 0.5 de cualquiera de los dos limites, imprimir:
#
#       APROBADO - atencion, cerca del limite
#
#   Con lectura = 13.8 debe salir la advertencia.
#   Con lectura = 12.0 debe salir APROBADO normal.
# =============================================================
