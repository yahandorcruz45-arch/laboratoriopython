# 04 · Ciclos y listas

**Tiempo estimado:** 45 minutos
**Meta:** procesar muchos datos sin repetir código.

---

## Orden de trabajo

1. Abre **`reto.py`** e intenta arreglarlo.
2. Lee esta teoría.
3. Experimenta con **`ejemplos.py`**.

---

## El problema

Tu script de control de calidad funciona con **una** lectura. El supervisor tiene
**catorce**. Y la próxima semana tendrá otras catorce.

La solución obvia es copiar y pegar el bloque `if` catorce veces. Funciona... hasta que
sean 500 lecturas. Y cuando cambie el límite, hay que editar los 500 bloques.

Hay una forma mejor.

---

## Listas

Una lista guarda **varios valores en una sola variable**:

```python
lecturas = [12.4, 13.1, 9.8, 12.9, 15.7]
```

Corchetes `[ ]`, valores separados por comas.

```python
len(lecturas)      # 5   -> cuantos elementos tiene
lecturas[0]        # 12.4 -> el primero
lecturas[1]        # 13.1 -> el segundo
lecturas[-1]       # 15.7 -> el ultimo
```

> **Python cuenta desde 0.** El primer elemento es `lecturas[0]`, no `lecturas[1]`.
> Todos los lenguajes de programación modernos hacen esto. Te vas a acostumbrar.

Una lista puede guardar cualquier tipo:

```python
operadores = ["Maria", "Jose", "Ana"]
activos = [True, False, True]
```

---

## El ciclo `for`

```python
for lectura in lecturas:
    print(lectura)
```

Se lee: *"para cada `lectura` dentro de `lecturas`, haz esto"*.

Qué pasa por dentro:

1. Python toma el primer elemento y lo mete en la variable `lectura`.
2. Ejecuta el bloque indentado.
3. Toma el segundo elemento, lo mete en `lectura`, ejecuta otra vez.
4. Y así hasta que se acaben.

El nombre `lectura` **lo inventas tú**. Podría ser `x`, pero un nombre descriptivo hace
el código legible:

```python
for operador in operadores:     # bien
for x in operadores:            # funciona, pero peor
```

Igual que el `if`: la línea termina en `:` y el bloque va indentado con 4 espacios.

---

## El patrón acumulador

Este es **el patrón más importante del módulo**. Sirve para contar, sumar o promediar.

Tiene tres partes, y el orden es crítico:

```python
rechazos = 0                      # 1. ANTES del ciclo: empieza en cero

for lectura in lecturas:
    if lectura > LIMITE_ALTO:
        rechazos = rechazos + 1   # 2. DENTRO: crece

print("Rechazos:", rechazos)      # 3. DESPUES: muestra el resultado
```

La línea `rechazos = rechazos + 1` se lee: *"el nuevo valor de `rechazos` es el que
tenía, más uno"*.

### El error clásico

Si pones el `= 0` **dentro** del ciclo, se reinicia en cada vuelta y siempre termina
valiendo 0 o 1:

```python
for lectura in lecturas:
    rechazos = 0              # ❌ se borra 14 veces
    if lectura > LIMITE_ALTO:
        rechazos = rechazos + 1
```

Y si pones el `print` **dentro**, se imprime catorce veces en vez de una.

**Los cuatro espacios de sangría deciden esto.** Son la diferencia entre un programa
correcto y uno que da resultados absurdos.

---

## Sumar y promediar

```python
suma = 0

for lectura in lecturas:
    suma = suma + lectura

promedio = suma / len(lecturas)
print("Promedio:", round(promedio, 2))
```

Mismo patrón: inicializar fuera, acumular dentro, usar después.

---

## 💡 Si ya usaste Excel

Cuando escribes una fórmula en `C2` y la arrastras hacia abajo por 500 filas, Excel
aplica la misma fórmula a cada fila.

**`for` es arrastrar la fórmula.** La diferencia es que en Python funciona igual con 14
filas que con 14 millones, y no tienes que arrastrar nada.

Y el acumulador es lo que hace `CONTAR.SI` o `SUMAR.SI` — solo que aquí tú decides la
regla, por complicada que sea.

---

## Errores de este módulo

| Error | Causa |
|---|---|
| `SyntaxError: expected ':'` | Falta los dos puntos al final del `for` |
| `IndentationError` | El bloque del ciclo no está indentado |
| `IndexError: list index out of range` | Pediste `lecturas[14]` en una lista de 14 (va de 0 a 13) |
| `ZeroDivisionError` | Dividiste entre `len()` de una lista vacía |
| **Ningún error, pero resultado raro** | El acumulador o el `print` están del lado equivocado de la sangría |

> Esa última fila es la importante. **Un programa puede correr perfecto y estar mal.**
> Por eso siempre hay que revisar si el resultado tiene sentido.

---

## Reto +

Amplía `reto.py` para que produzca el reporte completo:

```
==== REPORTE DE PRODUCCION ====
Total de lecturas: 14
Rechazos: 4
Aprobadas: 10
Promedio: 12.24
Lectura mas alta: 15.7
Lectura mas baja: 8.3
===============================
```

Para la más alta y la más baja, intenta hacerlo **sin usar `max()` ni `min()`**: usa una
variable que se vaya actualizando dentro del ciclo.

---

**Siguiente:** [`05-funciones/`](../05-funciones/)
