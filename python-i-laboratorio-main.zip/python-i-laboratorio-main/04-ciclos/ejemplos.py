# =============================================================
# 04 · CICLOS Y LISTAS — Ejemplos
# =============================================================
# El supervisor no tiene UNA lectura. Tiene catorce.
# =============================================================


# --- 1. Una lista guarda varios valores ---------------------
lecturas = [12.4, 13.1, 9.8, 12.9, 15.7, 11.2, 12.0,
            8.3, 13.4, 12.6, 14.9, 12.2, 10.1, 12.8]

print("La lista completa:", lecturas)
print("Cuantos elementos tiene:", len(lecturas))


# --- 2. Acceder a un elemento por su posicion ---------------
# OJO: Python empieza a contar en 0, no en 1.
print("Primera lectura:", lecturas[0])
print("Segunda lectura:", lecturas[1])
print("Ultima lectura:", lecturas[-1])   # -1 es la ultima


# --- 3. El ciclo for: recorrer la lista ---------------------
print("---- recorriendo ----")

for lectura in lecturas:
    print("Lectura:", lectura)

# Se lee: "para cada lectura DENTRO DE lecturas, haz esto".
# 'lectura' es un nombre que tu inventas. En cada vuelta
# contiene un elemento distinto de la lista.


# --- 4. Acumulador: contar cosas ----------------------------
# El patron: empieza en 0 FUERA del ciclo, crece DENTRO.

LIMITE_BAJO = 10.0
LIMITE_ALTO = 14.0

rechazos = 0

for lectura in lecturas:
    if lectura < LIMITE_BAJO or lectura > LIMITE_ALTO:
        rechazos = rechazos + 1

print("---- conteo ----")
print("Total de rechazos:", rechazos)


# --- 5. Acumulador: sumar y promediar -----------------------
suma = 0

for lectura in lecturas:
    suma = suma + lectura

promedio = suma / len(lecturas)

print("Suma total:", round(suma, 2))
print("Promedio:", round(promedio, 2))


# --- 6. El reporte completo del supervisor ------------------
print()
print("==== REPORTE DE PRODUCCION ====")

rechazos = 0
suma = 0

for lectura in lecturas:
    suma = suma + lectura
    if lectura < LIMITE_BAJO or lectura > LIMITE_ALTO:
        rechazos = rechazos + 1
        print("  RECHAZADO:", lectura)

print("Total de lecturas:", len(lecturas))
print("Rechazos:", rechazos)
print("Aprobadas:", len(lecturas) - rechazos)
print("Promedio:", round(suma / len(lecturas), 2))
print("===============================")


# --- 7. Dentro o fuera del ciclo: la diferencia -------------
print()
print("---- print DENTRO del ciclo ----")
contador = 0
for lectura in lecturas:
    contador = contador + 1
    print("Van", contador)      # imprime 14 veces

print("---- print FUERA del ciclo ----")
contador = 0
for lectura in lecturas:
    contador = contador + 1
print("Van", contador)          # imprime 1 vez, al final

# La UNICA diferencia son los 4 espacios de sangria.


# =============================================================
# AHORA TE TOCA A TI
# =============================================================
#   A) Agrega dos lecturas mas a la lista y ejecuta otra vez.
#      Tuviste que cambiar algo mas? Por que no?
#
#   B) Cuenta cuantas lecturas estan por DEBAJO del limite
#      (solo las bajas, no las altas).
#
#   C) Encuentra la lectura mas alta de la lista SIN usar
#      max(). Pista: usa una variable que empiece en 0 y se
#      actualice cuando encuentres algo mayor.
# =============================================================
