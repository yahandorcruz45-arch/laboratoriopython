# =============================================================
# 04 · CICLOS Y LISTAS — Reto
# =============================================================
# SITUACION:
#   Este script deberia contar los rechazos y sacar el promedio
#   de las 14 lecturas. Tiene 3 errores.
#
#   Uno de ellos NO detiene el programa: simplemente da un
#   resultado equivocado. Esos son los mas peligrosos.
# =============================================================


lecturas = [12.4, 13.1, 9.8, 12.9, 15.7, 11.2, 12.0,
            8.3, 13.4, 12.6, 14.9, 12.2, 10.1, 12.8]

LIMITE_BAJO = 10.0
LIMITE_ALTO = 14.0


# Error 1: falta algo al final de esta linea
for lectura in lecturas

    # Error 2: el acumulador se reinicia en cada vuelta
    rechazos = 0

    if lectura < LIMITE_BAJO or lectura > LIMITE_ALTO:
        rechazos = rechazos + 1

# Error 3: esta linea esta dentro del ciclo y no deberia
    print("Total de rechazos:", rechazos)


# =============================================================
# RESULTADO ESPERADO:
#
#   Total de rechazos: 4
#
#   (Una sola linea. Los rechazos son: 9.8, 15.7, 8.3, 14.9)
# =============================================================


# =============================================================
# RETO +  (solo si ya terminaste)
# =============================================================
#   Amplia el script para que tambien calcule e imprima:
#     - El promedio de todas las lecturas (2 decimales)
#     - Cuantas quedaron aprobadas
#     - La lectura mas alta y la mas baja
# =============================================================
