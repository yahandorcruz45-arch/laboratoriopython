# 05 · Funciones

**Tiempo estimado:** 30 minutos
**Meta:** empaquetar código para reutilizarlo.

---

## Orden de trabajo

1. Abre **`reto.py`** e intenta arreglarlo.
2. Lee esta teoría.
3. Experimenta con **`ejemplos.py`**.

---

## El problema

Tu chequeo de calidad funciona. Ahora el supervisor te dice que hay **tres máquinas**, y
cada una tiene límites distintos.

Podrías copiar el bloque completo tres veces cambiando los números. Pero entonces, cuando
haya que corregir la lógica, hay que corregirla en tres lugares — y seguro se te olvida uno.

---

## Qué es una función

Una función es **un bloque de código con nombre**, que puedes ejecutar cuando quieras,
las veces que quieras.

Ya vienes usando funciones todo el día: `print()`, `len()`, `int()`, `round()`. Alguien
las escribió para que tú no tengas que hacerlo. Ahora te toca escribir las tuyas.

```python
def saludar():
    print("Bienvenido al control de calidad")
```

- `def` — *define*, la palabra que inicia una función
- `saludar` — el nombre que tú le pones
- `()` — los paréntesis (por ahora vacíos)
- `:` y el bloque indentado — igual que en `if` y `for`

**Definir una función no la ejecuta.** Es como escribir una receta: no cocina nada. Para
ejecutarla hay que **llamarla**:

```python
saludar()
```

---

## Parámetros: los datos que cambian

```python
def saludar_operador(nombre):
    print("Bienvenido,", nombre)

saludar_operador("Maria")     # Bienvenido, Maria
saludar_operador("Jose")      # Bienvenido, Jose
```

`nombre` es un **parámetro**: un hueco que se rellena cada vez que llamas la función.

Puedes tener varios, separados por comas:

```python
def evaluar(lectura, limite_bajo, limite_alto):
    ...

evaluar(15.7, 10.0, 14.0)
```

> **El orden importa.** El primer valor va al primer parámetro, el segundo al segundo. Si
> los inviertes, Python no se queja — simplemente da un resultado equivocado.

Y si te falta uno, sí se queja:

```
TypeError: evaluar() missing 1 required positional argument: 'limite_alto'
```

---

## `return`: devolver un resultado

Esta es la parte que más confunde, y vale la pena entenderla bien.

| | Qué hace |
|---|---|
| `print(x)` | **Muestra** `x` en pantalla. Se acabó. |
| `return x` | **Devuelve** `x` al programa, para seguir usándolo. |

```python
def evaluar(lectura, limite_bajo, limite_alto):
    if lectura < limite_bajo:
        return "RECHAZADO BAJO"
    elif lectura > limite_alto:
        return "RECHAZADO ALTO"
    else:
        return "APROBADO"
```

Como devuelve un valor, puedes guardarlo, compararlo, meterlo en otra función:

```python
resultado = evaluar(15.7, 10.0, 14.0)

if resultado == "APROBADO":
    print("Puede continuar")
```

Con `print` no podrías hacer eso. Una función que solo imprime devuelve `None`, que es
la forma de Python de decir *"nada"*:

```python
def sumar_mal(a, b):
    print(a + b)

x = sumar_mal(2, 3)
print(x)            # None
```

> **Regla práctica:** una función debería **calcular y devolver**. Quien la llama decide
> si imprime el resultado, lo guarda o lo usa para otra cosa.

`return` también termina la función de inmediato: nada después de un `return` ejecutado
se ejecuta.

---

## Por qué vale la pena

Tres razones concretas:

1. **No te repites.** El mismo código sirve para tres máquinas, o para trescientas.
2. **Un solo lugar que corregir.** Si la lógica cambia, la cambias una vez.
3. **Se lee mejor.** `contar_rechazos(lecturas, 10.0, 14.0)` dice qué hace. Un bloque de
   quince líneas hay que descifrarlo.

---

## 💡 Si ya usaste Excel

`PROMEDIO()`, `SUMA()`, `BUSCARV()` son funciones: les das datos, te devuelven un
resultado. Nunca te preguntaste cómo funcionan por dentro — solo las usas.

La diferencia es que en Excel estás limitado a las que Microsoft incluyó. En Python
escribes las tuyas, con la lógica que tu trabajo necesite.

---

## Errores de este módulo

| Error | Causa |
|---|---|
| `SyntaxError` en la línea del `def` | Falta `def`, los paréntesis o los dos puntos |
| `TypeError: missing 1 required positional argument` | Llamaste la función con menos datos de los que pide |
| `TypeError: takes 2 positional arguments but 3 were given` | Le pasaste datos de más |
| `NameError: name 'evaluar' is not defined` | Llamaste la función antes de definirla, o mal escrita |
| Imprime `None` | La función usa `print` donde debería usar `return` |

---

## Reto +

Escribe `generar_reporte(lista, bajo, alto)` que use las otras funciones y muestre el
reporte completo. Pruébala con las dos máquinas extra que están al final de `reto.py`.

---

**Siguiente:** [`06-proyecto-final/`](../06-proyecto-final/)
