# =============================================================
# 05 · FUNCIONES — Ejemplos
# =============================================================
# Ahora hay 3 maquinas, y cada una tiene limites distintos.
# =============================================================


# --- 1. Ya vienes usando funciones --------------------------
# print(), len(), int(), round() son funciones que ya existen.
print(len("produccion"))
print(round(12.3456, 2))

# Ahora vas a escribir las tuyas.


# --- 2. Tu primera funcion ----------------------------------
def saludar():
    print("Bienvenido al control de calidad")

# Definirla NO la ejecuta. Hay que llamarla:
saludar()
saludar()   # y se puede llamar las veces que quieras


# --- 3. Funciones con parametros ----------------------------
# Los parametros son "los datos que cambian en cada uso".

def saludar_operador(nombre):
    print("Bienvenido,", nombre)

saludar_operador("Maria")
saludar_operador("Jose")


# --- 4. return: devolver un resultado -----------------------
# print MUESTRA en pantalla. return DEVUELVE un valor que el
# programa puede seguir usando. No son lo mismo.

def evaluar(lectura, limite_bajo, limite_alto):
    if lectura < limite_bajo:
        return "RECHAZADO BAJO"
    elif lectura > limite_alto:
        return "RECHAZADO ALTO"
    else:
        return "APROBADO"


print("---- tres maquinas, tres limites ----")
print(evaluar(15.7, 10.0, 14.0))   # maquina A
print(evaluar(12.1, 11.0, 13.0))   # maquina B
print(evaluar(9.5, 8.0, 10.0))     # maquina C

# La MISMA funcion sirve para las tres. Eso es lo que ganas.


# --- 5. La diferencia entre print y return ------------------
def suma_con_print(a, b):
    print(a + b)          # lo muestra

def suma_con_return(a, b):
    return a + b          # lo devuelve

print("---- print vs return ----")

suma_con_print(2, 3)                 # muestra 5
resultado = suma_con_return(2, 3)    # guarda 5 en 'resultado'
print("Puedo seguir usandolo:", resultado * 10)

# Con la primera no puedes hacer eso: no devuelve nada.
guardado = suma_con_print(2, 3)
print("Lo que devolvio la de print:", guardado)   # None


# --- 6. Funciones + ciclos: el reporte completo -------------
lecturas = [12.4, 13.1, 9.8, 12.9, 15.7, 11.2, 12.0,
            8.3, 13.4, 12.6, 14.9, 12.2, 10.1, 12.8]


def contar_rechazos(lista, limite_bajo, limite_alto):
    total = 0
    for valor in lista:
        if valor < limite_bajo or valor > limite_alto:
            total = total + 1
    return total


def calcular_promedio(lista):
    suma = 0
    for valor in lista:
        suma = suma + valor
    return round(suma / len(lista), 2)


print()
print("==== REPORTE ====")
print("Rechazos:", contar_rechazos(lecturas, 10.0, 14.0))
print("Promedio:", calcular_promedio(lecturas))
print("=================")


# =============================================================
# AHORA TE TOCA A TI
# =============================================================
#   A) Llama a evaluar() con una lectura tuya y limites tuyos.
#
#   B) Escribe una funcion calcular_itbis(monto) que devuelva
#      el monto con 18% agregado.
#
#   C) En la funcion evaluar(), cambia los 'return' por 'print'
#      y ejecuta el bloque 4 otra vez. Que salio? Por que?
#      Luego devuelvelo como estaba.
# =============================================================
