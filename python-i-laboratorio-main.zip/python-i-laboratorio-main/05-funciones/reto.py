# =============================================================
# 05 · FUNCIONES — Reto
# =============================================================
# SITUACION:
#   Hay que evaluar lecturas de 3 maquinas con limites distintos.
#   Este script tiene 3 errores.
# =============================================================


# Error 1: falta la palabra clave que define una funcion
evaluar(lectura, limite_bajo, limite_alto):
    if lectura < limite_bajo:
        return "RECHAZADO BAJO"
    elif lectura > limite_alto:
        return "RECHAZADO ALTO"
    else:
        return "APROBADO"


# Error 2: esta funcion no devuelve nada, solo muestra
def calcular_promedio(lista):
    suma = 0
    for valor in lista:
        suma = suma + valor
    print(round(suma / len(lista), 2))


lecturas_maquina_a = [12.4, 13.1, 9.8, 12.9, 15.7]

print("Maquina A")
print(evaluar(15.7, 10.0, 14.0))

# Error 3: a esta llamada le falta un dato
print(evaluar(12.1, 11.0))

promedio = calcular_promedio(lecturas_maquina_a)
print("Promedio maquina A:", promedio)


# =============================================================
# RESULTADO ESPERADO:
#
#   Maquina A
#   RECHAZADO ALTO
#   APROBADO
#   Promedio maquina A: 12.78
#
# OJO con el error 2: el programa NO se detiene por el,
# pero la ultima linea imprime "None" en vez del promedio.
# Por que? Cual es la diferencia entre print y return?
# =============================================================


# =============================================================
# RETO +  (solo si ya terminaste)
# =============================================================
#   Escribe una funcion generar_reporte(lista, bajo, alto) que
#   use las otras dos funciones y muestre el reporte completo:
#   total de lecturas, rechazos, aprobadas y promedio.
#
#   Luego llamala con estas dos maquinas:
#     maquina_b = [11.5, 12.8, 13.9, 10.2]   limites 11.0 - 13.0
#     maquina_c = [8.9, 9.4, 10.5, 7.2]      limites  8.0 - 10.0
# =============================================================
