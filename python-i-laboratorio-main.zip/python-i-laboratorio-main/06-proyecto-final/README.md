# 06 · Proyecto final

**Tiempo estimado:** 30 minutos
**Meta:** demostrar que puedes leer código ajeno y escribir código propio.

Dos ejercicios. Los dos se entregan.

---

## Reto 1 · Diagnóstico y reparación

📁 [`reto-1-diagnostico/`](reto-1-diagnostico/)

Te llegó un script de otro pasante que ya terminó su rotación. Se supone que genera el
reporte semanal de producción. **Tiene 4 errores.**

Algunos detienen el programa. Otros no: el script corre completo y entrega un número
equivocado. Esos son los peligrosos — nadie se entera hasta que alguien toma una
decisión con datos malos.

### Qué hacer

1. **Lee el script completo antes de ejecutarlo.** Esto es lo que hace un técnico cuando
   hereda código: primero entender, después tocar.
2. Abre `RESPUESTAS.md` y escribe qué hace el script.
3. Ejecútalo, encuentra los 4 errores y arréglalos.
4. Documenta cada error en `RESPUESTAS.md`.

### Se entrega

- `reporte_semanal.py` corregido y funcionando
- `RESPUESTAS.md` completo

---

## Reto 2 · Tu propio script

📁 [`reto-2-mi-script/`](reto-2-mi-script/)

Aquí se acaba el escenario ficticio. Ahora es tu trabajo real.

> **Piensa en una tarea que hagas —o veas hacer— en tu pasantía, que sea repetitiva y
> siga una regla. Escribe un script que la automatice.**
>
> No tiene que ser perfecto ni completo. **Tiene que correr.**

Abre `automatiza_mi_tarea.py`: tiene la estructura en cuatro pasos y te indica dónde
escribir. Al lado hay un `EJEMPLO_RESUELTO.py` para que veas cómo se ve uno terminado —
es referencia, no plantilla para copiar.

### Requisitos

Tu script debe tener:

1. Un encabezado con tu nombre, tu empresa y qué tarea automatiza
2. Al menos **2 variables** con nombres descriptivos
3. Al menos **1 condicional** (`if`)
4. Al menos **1 ciclo** (`for`) sobre una lista
5. Al menos **1 función propia** con `return`
6. Que **ejecute sin errores**

---

### ¿No se te ocurre nada?

Normal. Elige una de estas y adáptala a tu contexto — todas se resuelven con exactamente
lo que viste hoy:

| Tarea | Qué haría el script |
|---|---|
| **Lecturas de sensor** | Validar una lista de mediciones contra un rango y contar las que se salen |
| **Tickets de soporte** | Clasificar tickets por carga diaria y contar los pendientes |
| **Inventario** | Revisar cantidades y marcar lo que está bajo el stock mínimo |
| **Horas trabajadas** | Sumar horas de la semana y señalar los días incompletos |
| **Garantías de equipos** | Revisar años de antigüedad y marcar lo que está fuera de garantía |
| **Consumo eléctrico** | Comparar lecturas mensuales y detectar picos anormales |
| **Control de temperatura** | Verificar una lista de temperaturas contra un rango seguro |

No pierdas más de cinco minutos decidiendo. **Escoge una y empieza.**

---

## Cómo se evalúa

Cumple / No cumple. No se evalúa elegancia ni optimización.

| Criterio | Qué se verifica |
|---|---|
| **Ejecuta** | Corre de principio a fin sin lanzar error |
| **Usa los cuatro elementos** | Variables, condicional, ciclo, función |
| **Está conectado** | El encabezado describe una tarea real de tu pasantía |
| **Es legible** | Los nombres de las variables dicen qué contienen |

---

## Entrega

Guarda los dos archivos y entrégalos por el medio que indique el facilitador.

---

## Y después de hoy

Lo que escribiste hoy es un script básico. Con lo que viene en Python II —archivos,
librerías, conexión a datos reales— este mismo script puede convertirse en algo que tu
empresa de pasantía use de verdad.

Guárdalo. Súbelo a tu GitHub. Es el primer elemento de tu portafolio.

---

**Volver al** [inicio](../README.md)
