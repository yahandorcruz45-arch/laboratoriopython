# Reto 1 — Hoja de respuestas

**Nombre:**
**Empresa de pasantía:**
**Fecha:**

---

## Parte A · ¿Qué hace este script?

Explica en tus propias palabras, **sin copiar el código**. Tres o cuatro líneas bastan.

> *(Escribe aquí)*

---

### A.1 — ¿Qué datos de entrada usa?

> *(Escribe aquí)*

### A.2 — ¿Qué resultados produce?

> *(Escribe aquí)*

### A.3 — ¿Para qué sirve cada función?

| Función | Qué hace |
|---|---|
| `evaluar_dia` | |
| `calcular_total` | |
| `calcular_promedio` | |

---

## Parte B · Los 4 errores

Para cada uno: la línea, qué estaba mal, y cómo lo arreglaste.

### Error 1

- **Línea:**
- **Qué estaba mal:**
- **Cómo lo arreglé:**
- **¿Detenía el programa o daba un resultado equivocado en silencio?**

### Error 2

- **Línea:**
- **Qué estaba mal:**
- **Cómo lo arreglé:**
- **¿Detenía el programa o daba un resultado equivocado en silencio?**

### Error 3

- **Línea:**
- **Qué estaba mal:**
- **Cómo lo arreglé:**
- **¿Detenía el programa o daba un resultado equivocado en silencio?**

### Error 4

- **Línea:**
- **Qué estaba mal:**
- **Cómo lo arreglé:**
- **¿Detenía el programa o daba un resultado equivocado en silencio?**

---

## Parte C · La pregunta importante

Dos de estos errores **no detenían el programa**. El script corría completo y entregaba
un reporte con números equivocados.

**Si nadie revisa, ¿qué consecuencia podría tener eso en una empresa real?**

> *(Escribe aquí)*

---

## Parte D · Verificación final

- [ ] El script corre sin errores
- [ ] La salida coincide exactamente con la esperada
- [ ] Puedo explicar qué hace cada una de las tres funciones
