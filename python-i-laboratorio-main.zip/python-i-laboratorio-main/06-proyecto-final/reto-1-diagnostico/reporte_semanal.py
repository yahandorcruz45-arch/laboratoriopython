# =============================================================
# PROYECTO FINAL · RETO 1 — Diagnostico y reparacion
# =============================================================
# Este script llego de otro pasante que ya termino su rotacion.
# Se supone que genera el reporte semanal de un operador.
#
# TIENE 4 ERRORES.
#
# Algunos detienen el programa. Otros NO: el programa corre
# completo y entrega un numero equivocado. Esos son los que
# de verdad causan problemas en el trabajo real.
#
# TU TRABAJO:
#   1. Leelo COMPLETO antes de ejecutarlo.
#   2. Escribe en RESPUESTAS.md que hace el script.
#   3. Ejecutalo, encuentra los 4 errores y arreglalos.
#   4. Anota cada error en RESPUESTAS.md.
# =============================================================


# ---------------- Configuracion ----------------
META_DIARIA = 100

piezas_por_dia = [112, 95, 130, 88, 100]


# ---------------- Funciones ----------------

def evaluar_dia(piezas, meta):
    """Dice si un dia cumplio la meta de produccion."""
    if piezas > meta:
        return "META CUMPLIDA"
    else:
        return "POR DEBAJO"


def calcular_total(lista):
    """Suma todas las piezas de la semana."""
    total = 0
    for valor in lista:
        total = total + valor
    return total


def calcular_promedio(lista):
    """Calcula el promedio diario de piezas."""
    promedio = calcular_total(lista) / len(lista)
    print(round(promedio, 2))


# ---------------- Programa principal ----------------

print("===== REPORTE SEMANAL DE PRODUCCION =====")
print("Meta diaria:", META_DIARIA, "piezas")
print()

dia_numero = 0

for piezas in piezas_por_dia:
    dias_cumplidos = 0
    dia_numero = dia_numero + 1

    estado = evaluar_dia(piezas, META_DIARIA)
    print("Dia", dia_numero, "-", piezas, "piezas -", estado)

    if estado == "META CUMPLIDA":
        dias_cumplidos = dias_cumplidos + 1

print()
print("Total de la semana:", calcular_total(piezas_por_dia))
print("Promedio diario:", calcular_promedio(piezas_por_dia))
print("Dias que cumplieron la meta: " + dias_cumplidos)
print("=========================================")


# =============================================================
# ASI DEBE QUEDAR LA SALIDA CUANDO ESTE ARREGLADO:
#
#   ===== REPORTE SEMANAL DE PRODUCCION =====
#   Meta diaria: 100 piezas
#
#   Dia 1 - 112 piezas - META CUMPLIDA
#   Dia 2 - 95 piezas - POR DEBAJO
#   Dia 3 - 130 piezas - META CUMPLIDA
#   Dia 4 - 88 piezas - POR DEBAJO
#   Dia 5 - 100 piezas - META CUMPLIDA
#
#   Total de la semana: 525
#   Promedio diario: 105.0
#   Dias que cumplieron la meta: 3
#   =========================================
#
# PISTA IMPORTANTE:
#   El dia 5 produjo exactamente 100 piezas, que es la meta.
#   Presta atencion a como se compara eso.
# =============================================================
