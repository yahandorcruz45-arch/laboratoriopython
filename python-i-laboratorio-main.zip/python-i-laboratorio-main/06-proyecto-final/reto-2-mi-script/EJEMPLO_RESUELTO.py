# =============================================================
# EJEMPLO RESUELTO — Solo como referencia
# =============================================================
# ESTE NO ES TU ENTREGABLE. Es un ejemplo de como se ve un
# script terminado. El tuyo debe resolver TU tarea, no esta.
#
#   NOMBRE: Ana Batista
#   EMPRESA DE PASANTIA: Soporte tecnico - CompuRed SRL
#   QUE TAREA AUTOMATIZA: Reviso a mano los tickets de soporte
#   de la semana para saber que dias tuvimos sobrecarga y
#   cuantos tickets quedaron sin cerrar.
# =============================================================


# ---------------- PASO 1 · Datos ----------------
dias = 5
tickets_recibidos = [12, 8, 15, 3, 9]
tickets_cerrados = [10, 8, 11, 3, 7]

LIMITE_SOBRECARGA = 10


# ---------------- PASO 2 · Funciones ----------------

def clasificar_dia(cantidad, limite):
    """Dice si un dia estuvo sobrecargado."""
    if cantidad > limite:
        return "SOBRECARGA"
    else:
        return "NORMAL"


def sumar_lista(lista):
    """Suma todos los valores de una lista."""
    total = 0
    for valor in lista:
        total = total + valor
    return total


# ---------------- PASO 3 · Ciclo y decisiones ----------------

dias_con_sobrecarga = 0
numero_dia = 0

print("===== TICKETS DE LA SEMANA =====")

for cantidad in tickets_recibidos:
    numero_dia = numero_dia + 1
    estado = clasificar_dia(cantidad, LIMITE_SOBRECARGA)

    print("Dia", numero_dia, "-", cantidad, "tickets -", estado)

    if estado == "SOBRECARGA":
        dias_con_sobrecarga = dias_con_sobrecarga + 1


# ---------------- PASO 4 · Reporte ----------------

total_recibidos = sumar_lista(tickets_recibidos)
total_cerrados = sumar_lista(tickets_cerrados)
pendientes = total_recibidos - total_cerrados

print()
print("Total recibidos:", total_recibidos)
print("Total cerrados:", total_cerrados)
print("Pendientes:", pendientes)
print("Dias con sobrecarga:", dias_con_sobrecarga)
print("Promedio diario:", round(total_recibidos / dias, 2))
print("================================")
