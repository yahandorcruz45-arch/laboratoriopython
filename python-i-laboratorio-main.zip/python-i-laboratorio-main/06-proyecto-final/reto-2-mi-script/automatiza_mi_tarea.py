# =============================================================
# PROYECTO FINAL · RETO 2 — Mi script
# =============================================================
# Completa estos datos:
#
#   NOMBRE:
#   EMPRESA DE PASANTIA:
#   QUE TAREA AUTOMATIZA ESTE SCRIPT:
#
# =============================================================


# -------------------------------------------------------------
# PASO 1 · Tus datos
# -------------------------------------------------------------
# Escribe aqui los datos con los que vas a trabajar.
# Al menos una lista y un par de variables de configuracion.
#
# EJEMPLO (borralo y pon lo tuyo):
#
#   tickets_por_dia = [12, 8, 15, 3, 9]
#   LIMITE_ALERTA = 10

# TU CODIGO AQUI:



# -------------------------------------------------------------
# PASO 2 · Tu funcion
# -------------------------------------------------------------
# Escribe al menos una funcion que reciba datos y DEVUELVA
# un resultado con return.
#
# EJEMPLO (borralo y pon lo tuyo):
#
#   def clasificar(cantidad, limite):
#       if cantidad > limite:
#           return "DIA CARGADO"
#       else:
#           return "DIA NORMAL"

# TU CODIGO AQUI:



# -------------------------------------------------------------
# PASO 3 · Tu ciclo con decisiones
# -------------------------------------------------------------
# Recorre tu lista con un for. Dentro, usa un if para decidir
# algo, y lleva al menos un contador o acumulador.
#
# Acuerdate: el acumulador se inicializa ANTES del ciclo.

# TU CODIGO AQUI:



# -------------------------------------------------------------
# PASO 4 · Tu reporte
# -------------------------------------------------------------
# Imprime el resultado final de forma clara y legible.

# TU CODIGO AQUI:



# =============================================================
# ANTES DE ENTREGAR, VERIFICA:
#
#   [ ] Complete el encabezado con mi nombre y mi empresa
#   [ ] El script corre sin errores
#   [ ] Use al menos 2 variables con nombres descriptivos
#   [ ] Use al menos 1 condicional (if)
#   [ ] Use al menos 1 ciclo (for) sobre una lista
#   [ ] Escribi al menos 1 funcion propia con return
#   [ ] La tarea que automatiza es REAL, de mi pasantia
# =============================================================
